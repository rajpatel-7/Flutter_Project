import 'package:admin_side/user/splashscreen/SplashScreen.dart';
import 'package:flutter/material.dart';



void main()
{
  runApp
    (
      MaterialApp
      (
          home:SplashScreen(),
          debugShowCheckedModeBanner: false,
      )
    );
}
