package com.example.andmin_side

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
